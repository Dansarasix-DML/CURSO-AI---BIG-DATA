
% Base de conocimientos
enfermedad("deficiencia de hierro").
enfermedad("mildiu").
enfermedad("exceso de riego").
enfermedad("roya").

sintoma("manchas amarillas").
sintoma("clorosis").
sintoma("marchitamiento de hojas").
sintoma("manchas moradas").
sintoma("crecimiento lento").
sintoma("podredumbre radicular").

farmaco("hierro").
farmaco("fungicida").
farmaco("reducir riego").

planta("rosa").
planta("tomate").
planta("girasol").

planta_padece("rosa", "manchas amarillas").
planta_padece("rosa", "clorosis").
planta_padece("tomate", "manchas amarillas").
planta_padece("tomate", "marchitamiento de hojas").
planta_padece("girasol", "manchas moradas").
planta_padece("girasol", "crecimiento lento").

pertenece_enfermedad("clorosis", "deficiencia de hierro").
pertenece_enfermedad("hongos", "mildu").
pertenece_enfermedad("manchas amarillas", "hongos").
pertenece_enfermedad("podredumbre radicular", "exceso de riego").
pertenece_enfermedad("manchas moradas", "podredumbre radicular").
pertenece_enfermedad("hongos", "roya").
pertenece_enfermedad("marchitamiento de hojas", "exceso de riego").

tratamiento("hierro", "clorosis").
tratamiento("fungicida", "mildiu").
tratamiento("fungicida", "roya").
tratamiento("reducir riego", "podredumbre radicular").


% Reglas
cura_enfermedad(Farmaco, Enfermedad):-
    tratamiento(Farmaco, Sintoma),
    pertenece_enfermedad(Sintoma, Enfermedad),
	format('El fármaco sirve contra: ~w~n', [Enfermedad]).

busca_farmaco(Enfermedad):-
    pertenece_enfermedad(Sintoma, Enfermedad),
    tratamiento(Farmaco, Sintoma),
    format('~w~n', [Farmaco]).

tiene_enfermedad(Planta):-
    planta_padece(Planta, Sintoma),
    pertenece_enfermedad(Sintoma, Enfermedad),
    format('La planta tiene: ~w~n', [Enfermedad]).

tiene_sintoma(Planta):-
	planta_padece(Planta, Sintoma),
	format('La planta tiene este sintoma: ~w~n', [Sintoma]).

listar_enfermos(Sintoma):-
	planta_padece(Planta, Sintoma),
	format('~w~n', [Planta]).

sintomas_comunes(P1, P2):-
    planta_padece(P1, Sintoma),
    planta_padece(P2, Sintoma),
    format('~w~n', [Sintoma]).

tratar_enfermedad(Planta, Enfermedad):-
    planta_padece(Planta, Sintoma),
    pertenece_enfermedad(Sintoma, Enfermedad),
    tratamiento(Farmaco, Enfermedad),
    format('Esta planta necesita: ~w~n', [Farmaco]).



